



/**
 * This file will hold wrapper for systems, which do not support pthreads
 */

/* create fake symbol to avoid empty trnaslation unit warning */
int g_ZSTD_threading_useles_symbol;





