
/*
	approximation_coding.h
*/


#include "debug.h"
#include "file_op.h"
#include "parse_config.h"

int approximation_coding_u16(char* input_filename, int width);
int approximation_coding_u16_advanced(char* input_filename, int width);






