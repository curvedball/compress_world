## Project Support Notice

The VS2005 Project directory has been moved to the contrib directory in order to indicate that it will no longer be supported.
