


#ifndef PLATFORM_H_MODULE
#define PLATFORM_H_MODULE


#if defined (__cplusplus)
extern "C" {
#endif



#define __64BIT__  1


#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200112L  /* use feature test macro */
#endif


#include <unistd.h>  /* declares _POSIX_VERSION */


//
#define PLATFORM_POSIX_VERSION _POSIX_VERSION



#include <unistd.h>   /* isatty */


//
#define IS_CONSOLE(stdStream) isatty(fileno(stdStream))




#define SET_BINARY_MODE(file)
#define SET_SPARSE_FILE_MODE(file)




//
#define ZSTD_SPARSE_DEFAULT 1




#if defined (__cplusplus)
}
#endif



#endif




