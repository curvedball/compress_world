
#include "netflow_v5.h"


int v5_field_width[V5_FIELD_NUM] = 
{
	4, 4, 4, 2, 2, 4, 4, 4, 4, 2, 2, 1, 1, 1, 1, 4, 4
};



