

#include "netflow_v9.h"



//39 columns
int v9_field_width[V9_FIELD_NUM] = 
{
	4, 4, 1, 1, 1, 2, 4, 2, 4, 8, 8
};





