
#ifndef ERROR_PUBLIC_H_MODULE
#define ERROR_PUBLIC_H_MODULE

#if defined (__cplusplus)
extern "C" {
#endif


/* *****************************************
 *  error codes list
 ******************************************/
typedef enum
{
    FSE_error_no_error,
    FSE_error_GENERIC,
    FSE_error_dstSize_tooSmall,
    FSE_error_srcSize_wrong,
    FSE_error_corruption_detected,
    FSE_error_tableLog_tooLarge,
    FSE_error_maxSymbolValue_tooLarge,
    FSE_error_maxSymbolValue_tooSmall,
    FSE_error_workSpace_tooSmall,
    FSE_error_maxCode
} FSE_ErrorCode;

/* note : compare with size_t function results using FSE_getError() */


#if defined (__cplusplus)
}
#endif


#endif


