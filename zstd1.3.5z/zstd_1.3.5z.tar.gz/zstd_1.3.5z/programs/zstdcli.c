


/*-************************************
*  Tuning parameters
**************************************/
#ifndef ZSTDCLI_CLEVEL_DEFAULT
#define ZSTDCLI_CLEVEL_DEFAULT 3
#endif



#ifndef ZSTDCLI_CLEVEL_MAX
#define ZSTDCLI_CLEVEL_MAX 19   /* without using --ultra */
#endif



/*-************************************
*  Dependencies
**************************************/
#include "platform.h" /* IS_CONSOLE, PLATFORM_POSIX_VERSION */
#include "util.h"     /* UTIL_HAS_CREATEFILELIST, UTIL_createFileList */
#include <stdio.h>    /* fprintf(), stdin, stdout, stderr */
#include <string.h>   /* strcmp, strlen */
#include <errno.h>    /* errno */


#include "debug.h"
#include "fileio.h"   /* stdinmark, stdoutmark, ZSTD_EXTENSION */
#include "dibio.h"  /* ZDICT_cover_params_t, DiB_trainFromFiles() */


//
#define ZSTD_STATIC_LINKING_ONLY   /* ZSTD_maxCLevel */
#include "zstd.h"     /* ZSTD_VERSION_STRING */


/*-************************************
*  Constants
**************************************/
#define COMPRESSOR_NAME "zstd command line interface"


#ifndef ZSTD_VERSION
#define ZSTD_VERSION "v" ZSTD_VERSION_STRING
#endif


#define AUTHOR "Yann Collet"
#define WELCOME_MESSAGE "*** %s %i-bits %s, by %s ***\n", COMPRESSOR_NAME, (int)(sizeof(size_t)*8), ZSTD_VERSION, AUTHOR





#define KB *(1 <<10)
#define MB *(1 <<20)
#define GB *(1U<<30)


//
#define DISPLAY_LEVEL_DEFAULT 6


//
static const char*    g_defaultDictName 		= 	"dictionary";
static const unsigned g_defaultMaxDictSize		= 	110 KB;
static const int      g_defaultDictCLevel 		= 	3;
static const unsigned g_defaultSelectivityLevel = 	9;
static const unsigned g_defaultMaxWindowLog 	= 	27;





/*-************************************
*  Display Macros
**************************************/
#define DISPLAY(...)         fprintf(g_displayOut, __VA_ARGS__)
#define DISPLAYLEVEL(l, ...) { if (g_displayLevel>=l) { DISPLAY(__VA_ARGS__); } }


//
static int g_displayLevel = DISPLAY_LEVEL_DEFAULT;   /* zbzb === 0 : no display,  1: errors,  2 : + result + interaction + warnings,  3 : + progression,  4 : + information */
static FILE* g_displayOut;


/*-************************************
*  Command Line
**************************************/
static int usage(const char* programName)
{
    DISPLAY( "Usage : \n");
    DISPLAY( "      %s [args] [FILE(s)] [-o file] \n", programName);
    DISPLAY( "\n");
    DISPLAY( "FILE    : a filename \n");
    DISPLAY( "          with no FILE, or when FILE is - , read standard input\n");
    DISPLAY( "Arguments : \n");
    DISPLAY( " -#     : # compression level (1-%d, default: %d) \n", ZSTDCLI_CLEVEL_MAX, ZSTDCLI_CLEVEL_DEFAULT);
    DISPLAY( " -d     : decompression \n");
    DISPLAY( " -D file: use `file` as Dictionary \n");
    DISPLAY( " -o file: result stored into `file` (only if 1 input file) \n");
    DISPLAY( " -f     : overwrite output without prompting and (de)compress links \n");
    DISPLAY( "--rm    : remove source file(s) after successful de/compression \n");
    DISPLAY( " -k     : preserve source file(s) (default) \n");
    DISPLAY( " -h/-H  : display help/long help and exit \n");
    return 0;
}



static int usage_advanced(const char* programName)
{
    DISPLAY(WELCOME_MESSAGE);
    usage(programName);
    DISPLAY( "\n");
    DISPLAY( "Advanced arguments : \n");
    DISPLAY( " -V     : display Version number and exit \n");
    DISPLAY( " -v     : verbose mode; specify multiple times to increase verbosity\n");
    DISPLAY( " -q     : suppress warnings; specify twice to suppress errors too\n");
    DISPLAY( " -c     : force write to standard output, even if it is the console\n");
    DISPLAY( " -l     : print information about zstd compressed files \n");

	//
    DISPLAY( "--ultra : enable levels beyond %i, up to %i (requires more memory)\n", ZSTDCLI_CLEVEL_MAX, ZSTD_maxCLevel());
    DISPLAY( "--long[=#]: enable long distance matching with given window log (default: %u)\n", g_defaultMaxWindowLog);
    DISPLAY( "--fast[=#]: switch to ultra fast compression level (default: %u)\n", 1);
    DISPLAY( "--no-dictID : don't write dictID into header (dictionary compression)\n");
    DISPLAY( "--[no-]check : integrity check (default: enabled) \n");
    DISPLAY( " -r     : operate recursively on directories \n");
    DISPLAY( "--format=zstd : compress files to the .zstd format (default) \n");
    DISPLAY( "--format=gzip : compress files to the .gz format \n");
    DISPLAY( "--test  : test compressed file integrity \n");
    DISPLAY( "--[no-]sparse : sparse mode (default: enabled on file, disabled on stdout)\n");


    DISPLAY( " -M#    : Set a memory usage limit for decompression \n");
    DISPLAY( "--      : All arguments after \"--\" are treated as files \n");
    DISPLAY( "\n");

	//
    DISPLAY( "Dictionary builder : \n");
    DISPLAY( "--train ## : create a dictionary from a training set of files \n");
    DISPLAY( "--train-cover[=k=#,d=#,steps=#] : use the cover algorithm with optional args\n");
    DISPLAY( "--train-legacy[=s=#] : use the legacy algorithm with selectivity (default: %u)\n", g_defaultSelectivityLevel);
    DISPLAY( " -o file : `file` is dictionary name (default: %s) \n", g_defaultDictName);
    DISPLAY( "--maxdict=# : limit dictionary to specified size (default: %u) \n", g_defaultMaxDictSize);
    DISPLAY( "--dictID=# : force dictionary ID to specified value (default: random)\n");

    return 0;
}



static int badusage(const char* programName)
{
    DISPLAYLEVEL(1, "Incorrect parameters\n");
    if (g_displayLevel >= 2)
    {
        usage(programName);
    }
    return 1;
}



static void waitEnter(void)
{
    int unused;
    DISPLAY("Press enter to continue...\n");
    unused = getchar();
    (void)unused;
}


static const char* lastNameFromPath(const char* path)
{
    const char* name = path;
    if (strrchr(name, '/'))
    {
        name = strrchr(name, '/') + 1;
    }
    if (strrchr(name, '\\'))
    {
        name = strrchr(name, '\\') + 1;    /* windows */
    }
    return name;
}



/*! exeNameMatch() :
    @return : a non-zero value if exeName matches test, excluding the extension
   */
static int exeNameMatch(const char* exeName, const char* test)
{
    return !strncmp(exeName, test, strlen(test)) && (exeName[strlen(test)] == '\0' || exeName[strlen(test)] == '.');
}



static void errorOut(const char* msg)
{
    DISPLAY("%s \n", msg);
    exit(1);
}



/*! readU32FromChar() :
 * @return : unsigned integer value read from input in `char` format.
 *  allows and interprets K, KB, KiB, M, MB and MiB suffix.
 *  Will also modify `*stringPtr`, advancing it to position where it stopped reading.
 *  Note : function will exit() program if digit sequence overflows */
static unsigned readU32FromChar(const char** stringPtr)
{
    const char errorMsg[] = "error: numeric value too large";
    unsigned result = 0;
    while ((**stringPtr >='0') && (**stringPtr <='9'))
    {
        unsigned const max = (((unsigned)(-1)) / 10) - 1;
        if (result > max)
        {
            errorOut(errorMsg);
        }
        result *= 10, result += **stringPtr - '0', (*stringPtr)++ ;
    }
    if ((**stringPtr=='K') || (**stringPtr=='M'))
    {
        unsigned const maxK = ((unsigned)(-1)) >> 10;
        if (result > maxK)
        {
            errorOut(errorMsg);
        }
        result <<= 10;
        if (**stringPtr=='M')
        {
            if (result > maxK)
            {
                errorOut(errorMsg);
            }
            result <<= 10;
        }
        (*stringPtr)++;  /* skip `K` or `M` */
        if (**stringPtr=='i')
        {
            (*stringPtr)++;
        }
        if (**stringPtr=='B')
        {
            (*stringPtr)++;
        }
    }
    return result;
}



/** longCommandWArg() :
 *  check if *stringPtr is the same as longCommand.
 *  If yes, @return 1 and advances *stringPtr to the position which immediately follows longCommand.
 * @return 0 and doesn't modify *stringPtr otherwise.
 */
static unsigned longCommandWArg(const char** stringPtr, const char* longCommand)
{
    size_t const comSize = strlen(longCommand);
    int const result = !strncmp(*stringPtr, longCommand, comSize);
    if (result)
    {
        *stringPtr += comSize;
    }
    return result;
}




/**
 * parseCoverParameters() :
 * reads cover parameters from *stringPtr (e.g. "--train-cover=k=48,d=8,steps=32") into *params
 * @return 1 means that cover parameters were correct
 * @return 0 in case of malformed parameters
 */
static unsigned parseCoverParameters(const char* stringPtr, ZDICT_cover_params_t* params)
{
    memset(params, 0, sizeof(*params));
    for (; ;)
    {
        if (longCommandWArg(&stringPtr, "k="))
        {
            params->k = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
        if (longCommandWArg(&stringPtr, "d="))
        {
            params->d = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
        if (longCommandWArg(&stringPtr, "steps="))
        {
            params->steps = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
        return 0;
    }
    if (stringPtr[0] != 0)
    {
        return 0;
    }
    DISPLAYLEVEL(4, "cover: k=%u\nd=%u\nsteps=%u\n", params->k, params->d, params->steps);
    return 1;
}




/**
 * parseLegacyParameters() :
 * reads legacy dictioanry builter parameters from *stringPtr (e.g. "--train-legacy=selectivity=8") into *selectivity
 * @return 1 means that legacy dictionary builder parameters were correct
 * @return 0 in case of malformed parameters
 */
static unsigned parseLegacyParameters(const char* stringPtr, unsigned* selectivity)
{
    if (!longCommandWArg(&stringPtr, "s=") && !longCommandWArg(&stringPtr, "selectivity="))
    {
        return 0;
    }
    *selectivity = readU32FromChar(&stringPtr);
    if (stringPtr[0] != 0)
    {
        return 0;
    }
    DISPLAYLEVEL(4, "legacy: selectivity=%u\n", *selectivity);
    return 1;
}

static ZDICT_cover_params_t defaultCoverParams(void)
{
    ZDICT_cover_params_t params;
    memset(&params, 0, sizeof(params));
    params.d = 8;
    params.steps = 4;
    return params;
}




/** parseCompressionParameters() :
 *  reads compression parameters from *stringPtr (e.g. "--zstd=wlog=23,clog=23,hlog=22,slog=6,slen=3,tlen=48,strat=6") into *params
 *  @return 1 means that compression parameters were correct
 *  @return 0 in case of malformed parameters
 */
static unsigned parseCompressionParameters(const char* stringPtr, ZSTD_compressionParameters* params)
{
    for ( ; ;)
    {
        if (longCommandWArg(&stringPtr, "windowLog=") || longCommandWArg(&stringPtr, "wlog="))
        {
            params->windowLog = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "chainLog=") || longCommandWArg(&stringPtr, "clog="))
        {
            params->chainLog = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "hashLog=") || longCommandWArg(&stringPtr, "hlog="))
        {
            params->hashLog = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "searchLog=") || longCommandWArg(&stringPtr, "slog="))
        {
            params->searchLog = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "searchLength=") || longCommandWArg(&stringPtr, "slen="))
        {
            params->searchLength = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "targetLength=") || longCommandWArg(&stringPtr, "tlen="))
        {
            params->targetLength = readU32FromChar(&stringPtr);
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "strategy=") || longCommandWArg(&stringPtr, "strat="))
        {
            params->strategy = (ZSTD_strategy)(readU32FromChar(&stringPtr));
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
		
        if (longCommandWArg(&stringPtr, "overlapLog=") || longCommandWArg(&stringPtr, "ovlog="))
        {
            if (stringPtr[0]==',')
            {
                stringPtr++;
                continue;
            }
            else
            {
                break;
            }
        }
        DISPLAYLEVEL(4, "invalid compression parameter \n");
        return 0;
    }

    DISPLAYLEVEL(4, "windowLog=%d, chainLog=%d, hashLog=%d, searchLog=%d \n", params->windowLog, params->chainLog, params->hashLog, params->searchLog);
    DISPLAYLEVEL(4, "searchLength=%d, targetLength=%d, strategy=%d \n", params->searchLength, params->targetLength, params->strategy);

	//
    if (stringPtr[0] != 0)
    {
        return 0;    /* check the end of string */
    }
    return 1;
}



static void printVersion(void)
{
    DISPLAY(WELCOME_MESSAGE);
	
    /* format support */
    DISPLAYLEVEL(3, "*** supports: zstd");
    DISPLAYLEVEL(3, ", gzip");
    DISPLAYLEVEL(3, "\n");
    DISPLAYLEVEL(4, "_POSIX_C_SOURCE defined: %ldL\n", (long) _POSIX_C_SOURCE);
    DISPLAYLEVEL(4, "_POSIX_VERSION defined: %ldL \n", (long) _POSIX_VERSION);
    DISPLAYLEVEL(4, "PLATFORM_POSIX_VERSION defined: %ldL\n", (long) PLATFORM_POSIX_VERSION);
}


typedef enum 
{ 
	zom_compress, 
	zom_decompress, 
	zom_test, 
	zom_bench, 
	zom_train, 
	zom_list 
} zstd_operation_mode;



#define CLEAN_RETURN(i) { operationResult = (i); goto _end; }



//=====================================================
int main(int argCount, const char* argv[])
{
    int argNb,
        followLinks = 0,
        forceStdout = 0,
        lastCommand = 0,
        main_pause = 0,
        nbWorkers = 0,
        nextArgumentIsOutFileName = 0,
        operationResult = 0,
        separateFiles = 0,
        setRealTimePrio = 0,
        singleThread = 0,
        ultra=0;

	//
	DbgPrint("zb====main===begin...\n\n\n");

	//
    unsigned bench_nbSeconds = 3;   /* would be better if this value was synchronized from bench */
    size_t blockSize = 0;
    zstd_operation_mode operation = zom_compress;
    ZSTD_compressionParameters compressionParams;

	//
    int cLevel = ZSTDCLI_CLEVEL_DEFAULT;
    int cLevelLast = -1000000000;
	
    unsigned memLimit = 0;
    const char** filenameTable = (const char**)malloc(argCount * sizeof(const char*));   /* argCount >= 1 */
    unsigned filenameIdx = 0;
    const char* programName = argv[0];
    const char* outFileName = NULL;
    const char* dictFileName = NULL;
    const char* suffix = ZSTD_EXTENSION;

	//
    unsigned maxDictSize = g_defaultMaxDictSize;
    unsigned dictID = 0;
    int dictCLevel = g_defaultDictCLevel;
    unsigned dictSelect = g_defaultSelectivityLevel;

	//
    char* fileNamesBuf = NULL;
    unsigned fileNamesNb;

	//
    ZDICT_cover_params_t coverParams = defaultCoverParams();
    int cover = 1;

    if (filenameTable==NULL)
    {
        DISPLAY("zstd: %s \n", strerror(errno));
        exit(1);
    }
	
    filenameTable[0] = stdinmark;
    g_displayOut = stderr;
    programName = lastNameFromPath(programName);

	//
    memset(&compressionParams, 0, sizeof(compressionParams));

	//
	//================================================
    /* command switches */
    for (argNb=1; argNb<argCount; argNb++)
    {
        const char* argument = argv[argNb];
        if(!argument)
        {
            continue;    /* Protection if argument empty */
        }

		//================
        if (!strcmp(argument, "-")) /* "-" means stdin/stdout */
        {
            if (!filenameIdx)
            {
                filenameIdx=1, filenameTable[0]=stdinmark;
                outFileName=stdoutmark;
                g_displayLevel-=(g_displayLevel==2);
                continue;
            }
        }


		//================
        if (argument[0]=='-')
        {

            if (argument[1]=='-')
            {
				DbgPrint("zb===Not Supported!===\n\n\n");
				return -1;
            }

			//
            argument++;
            while (argument[0]!=0)
            {
                if (lastCommand)
                {
                    DISPLAY("error : command must be followed by argument \n");
                    CLEAN_RETURN(1);
                }

                /* compression Level */
                if ((*argument>='0') && (*argument<='9'))
                {
                    dictCLevel = cLevel = readU32FromChar(&argument);
                    continue;
                }

                switch(argument[0])
                {
                    case 'h':
                        g_displayOut=stdout;
                        CLEAN_RETURN(usage_advanced(programName));

                    /* Compress */
                    case 'z':
                        operation=zom_compress;
                        argument++;
                        break;

                    /* Decoding */
                    case 'd':
                        operation=zom_decompress;
                        argument++;
                        break;

                    /* Force Overwrite */
                    case 'f':
                        FIO_overwriteMode();
                        forceStdout=1;
                        followLinks=1;
                        argument++;
                        break;

                    /* destination file name */
                    case 'o':
                        nextArgumentIsOutFileName=1;
                        lastCommand=1;
                        argument++;
                        break;

                    default :
                        CLEAN_RETURN(badusage(programName));
                }
            }
            continue;
        }

		//
        if (nextArgumentIsOutFileName)
        {
            nextArgumentIsOutFileName = 0;
            lastCommand = 0;
            outFileName = argument;
            if (!strcmp(outFileName, "-"))
            {
                outFileName = stdoutmark;
            }
            continue;
        }

        /* add filename to list */
        filenameTable[filenameIdx++] = argument;
    }


	//=================================================
    if (lastCommand)   /* forgotten argument */
    {
        DISPLAY("error : command must be followed by argument \n");
        CLEAN_RETURN(1);
    }

    /* Welcome message (if verbose) */
    DISPLAYLEVEL(3, WELCOME_MESSAGE);
    g_utilDisplayLevel = g_displayLevel;

	//
    if (!followLinks)
    {
		DbgPrint("zb====followLinks===\n\n");
        unsigned u;
        for (u=0, fileNamesNb=0; u<filenameIdx; u++)
        {
            if (UTIL_isLink(filenameTable[u]))
            {
                DISPLAYLEVEL(2, "Warning : %s is a symbolic link, ignoring\n", filenameTable[u]);
            }
            else
            {
                filenameTable[fileNamesNb++] = filenameTable[u];
            }
        }
        filenameIdx = fileNamesNb;
    }

    /* No input filename ==> use stdin and stdout */
    filenameIdx += !filenameIdx;   /* filenameTable[0] is stdin by default */
 

    /* check compression level limits */
    {
        int const maxCLevel = ultra ? ZSTD_maxCLevel() : ZSTDCLI_CLEVEL_MAX;
        if (cLevel > maxCLevel)
        {
            DISPLAYLEVEL(2, "Warning : compression level higher than max, reduced to %i \n", maxCLevel);
            cLevel = maxCLevel;
        }
    }

    if ((filenameIdx>1) & (g_displayLevel==2))
    {
        g_displayLevel=1;
    }

	
    /* IO Stream/File */
    FIO_setNotificationLevel(g_displayLevel);

	//======================================
    if (operation==zom_compress)
    {
        FIO_setNbWorkers(nbWorkers);
        FIO_setBlockSize((U32)blockSize);

        if ((filenameIdx==1) && outFileName)
        {
            operationResult = FIO_compressFilename(outFileName, filenameTable[0], dictFileName, cLevel, &compressionParams);
        }
        else
        {
			//
			//zb: 
			//
            operationResult = FIO_compressMultipleFilenames(filenameTable, filenameIdx, outFileName, suffix, dictFileName, cLevel, &compressionParams); //zbzb
        }
    }
    else      /* decompression or test */
    {
        if (memLimit == 0)
        {
            if (compressionParams.windowLog == 0)
            {
                memLimit = (U32)1 << g_defaultMaxWindowLog;
            }
            else
            {
                memLimit = (U32)1 << (compressionParams.windowLog & 31);
            }
        }
		
        FIO_setMemLimit(memLimit);

		//
        if (filenameIdx==1 && outFileName)
        {
            operationResult = FIO_decompressFilename(outFileName, filenameTable[0], dictFileName);
        }
        else
        {
			//
			//zb: 
			//
            operationResult = FIO_decompressMultipleFilenames(filenameTable, filenameIdx, outFileName, dictFileName); //zbzb
        }
    }


	//
_end:
    if (main_pause)
    {
        waitEnter();
    }
	
	//
    free((void*)filenameTable);

    return operationResult;
}




